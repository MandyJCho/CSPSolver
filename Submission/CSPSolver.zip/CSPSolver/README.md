CSP Solver Instructions
Mandy Jung Cho written using intellij on MacOS

1) Compile src
    1) Navigate to CSPSolver/
    2) Create a source.txt file and fill it with the names of the files to compile by running the following command
        ` find . -name  "*.java" > source.txt `
    3) Compile the files 
        ` javac @source.txt `
    4) Navigate to the src folder
        ` cd src/ `
    5) Run the generated Main.class file
        ` java src/com.mandyjcho.Main <path to .var>  <path to .con> <fc | none> `
       

2) Run from out/
    1) Navigate to CSPSolver/out/production/CSPSolver/
    2) Run the following command
        ` java com.mandyjcho.Main <path to .var>  <path to .con> <fc | none> `

3) Run jar
    1) Navigate to CSPSolver/out/artifacts
    2) Run the following command     
         ` java -jar CSPSolver.jar <path to .var>  <path to .con> <fc | none> `

Arguments

The program takes 3 arguments:

    * path to .var 
    * path to .con
    * version of backtracking to run
  
  The options include:
  
    fc - backtracking with enable forward checking
    none - run normal backtracking
    